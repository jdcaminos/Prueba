package com.backend.apialquileres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class apialquileres {

	public static void main(String[] args) {
		SpringApplication.run(apialquileres.class, args);
	}

}
