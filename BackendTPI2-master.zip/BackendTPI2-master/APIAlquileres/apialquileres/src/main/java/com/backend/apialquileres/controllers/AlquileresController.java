package com.backend.apialquileres.controllers;

import com.backend.apialquileres.entitiesDTO.AlquileresDTO;
import com.backend.apialquileres.services.AlquileresServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alquileres")
public class AlquileresController {

   @Autowired
   private AlquileresServices alquileresServices;

    @GetMapping()
    public ResponseEntity<List<AlquileresDTO>> getAllAlquiler() {
        return ResponseEntity.ok(alquileresServices.getAllAlquiler());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AlquileresDTO> getAlquilerById(@PathVariable("id") Long id) {
        AlquileresDTO alquiler = alquileresServices.findById(id);
        if (alquiler != null) {
            return ResponseEntity.ok(alquiler);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping()
    public ResponseEntity<AlquileresDTO> createAlquiler(@RequestBody AlquileresDTO alquilerDto) {
        AlquileresDTO createdAlquiler = alquileresServices.save(alquilerDto);
        return ResponseEntity.ok(createdAlquiler);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AlquileresDTO> updateAlquiler(@PathVariable("id") Long id, @RequestBody AlquileresDTO alquilerDto) {
        AlquileresDTO updatedAlquiler = alquileresServices.update(id, alquilerDto);
        if (updatedAlquiler != null) {
            return ResponseEntity.ok(updatedAlquiler);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAlquiler(@PathVariable("id") Long id) {
        alquileresServices.deleteById(id);
        return ResponseEntity.noContent().build();
    }

}
