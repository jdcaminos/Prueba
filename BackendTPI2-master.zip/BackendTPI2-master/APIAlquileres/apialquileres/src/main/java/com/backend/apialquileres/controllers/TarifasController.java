package com.backend.apialquileres.controllers;

import com.backend.apialquileres.entitiesDTO.TarifasDTO;
import com.backend.apialquileres.services.TarifasServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tarifas")
public class TarifasController {
    @Autowired
    private TarifasServices tarifasServices;

    @GetMapping()
    public ResponseEntity<List<TarifasDTO>> getAllTarifas() {
        return ResponseEntity.ok(tarifasServices.getAllTarifas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TarifasDTO> getTarifaById(@PathVariable("id") Long id) {
        TarifasDTO tarifa = tarifasServices.findById(id);
        if (tarifa != null) {
            return ResponseEntity.ok(tarifa);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @PostMapping()
    public ResponseEntity<TarifasDTO> createTarifa(@RequestBody TarifasDTO tarifaDto) {
        TarifasDTO createdTarifa = tarifasServices.save(tarifaDto);
        return ResponseEntity.ok(createdTarifa);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TarifasDTO> updateTarifa(@PathVariable("id") Long id, @RequestBody TarifasDTO tarifaDto) {
        TarifasDTO updatedTarifa = tarifasServices.update(id, tarifaDto);
        if (updatedTarifa != null) {
            return ResponseEntity.ok(updatedTarifa);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTarifa(@PathVariable("id") Long id) {
        tarifasServices.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
