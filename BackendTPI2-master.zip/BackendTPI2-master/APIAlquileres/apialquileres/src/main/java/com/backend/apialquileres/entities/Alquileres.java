package com.backend.apialquileres.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ALQUILERES")
public class Alquileres {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private int id;
    @Column(name = "ID_CLIENTE")
    private char idCliente;
    @Column (name = "ESTADO")
    private int estado;
    @ManyToOne
    @JoinColumn (name = "ESTACION_RETIRO", referencedColumnName = "Id")
    private Estaciones estacionRetiro;
    @ManyToOne
    @JoinColumn (name = "ESTACION_DEVOLUCION", referencedColumnName = "Id")
    private Estaciones estacionDevolucion;
    @Column (name = "FECHA_HORA_RETIRO")
    private LocalDateTime fechaHoraRetiro;
    @Column (name = "FECHA_HORA_DEVOLUCION")
    private LocalDateTime fechaHoraDevolucion;
    @Column (name = "MONTO")
    private double monto;
    @ManyToOne
    @JoinColumn (name = "ID_TARIFA", referencedColumnName = "Id")
    private Tarifas idTarifa;
}
