package com.backend.apialquileres.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;

@Data
@Entity
@Table(name = "ESTACIONES")
public class Estaciones {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "NOMBRE")
    private char nombre;
    @Column(name = "FECHA_HORA_CREACION")
    private Timestamp fechaHoraCreacion;
    @Column(name = "LONGITUD")
    private float longitud;
    @Column(name = "LATITUD")
    private float latitud;

}
