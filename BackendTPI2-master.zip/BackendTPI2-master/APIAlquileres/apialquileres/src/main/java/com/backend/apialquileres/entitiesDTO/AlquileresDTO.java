package com.backend.apialquileres.entitiesDTO;

import com.backend.apialquileres.entities.Tarifas;
import com.backend.apialquileres.entities.Estaciones;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AlquileresDTO {
    private int id;
    private char idCliente;
    private int estado;
    private Estaciones estacionRetiro;
    private Estaciones estacionDevolucion;
    private LocalDateTime fechaHoraRetiro;
    private LocalDateTime fechaHoraDevolucion;
    private double monto;
    private Tarifas idTarifa;
}
