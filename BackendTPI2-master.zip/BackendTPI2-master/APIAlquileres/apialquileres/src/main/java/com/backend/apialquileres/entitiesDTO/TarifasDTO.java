package com.backend.apialquileres.entitiesDTO;

import lombok.Data;

@Data
public class TarifasDTO {
    private int id;
    private int tipoTarifa;
    private char definicion;
    private Integer diaSemana;
    private Integer diaMes;
    private Integer mes;
    private Integer anio;
    private double montoFijoAlquiler;
    private double montoMinutoFraccion;
    private double montoKm;
    private double montoHora;
}
