package com.backend.apialquileres.repository;

import com.backend.apialquileres.entities.Alquileres;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AlquileresRepository extends JpaRepository<Alquileres, Long> {
}
