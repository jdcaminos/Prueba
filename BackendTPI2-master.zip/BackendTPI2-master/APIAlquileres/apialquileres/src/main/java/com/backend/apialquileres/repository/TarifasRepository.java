package com.backend.apialquileres.repository;

import com.backend.apialquileres.entities.Tarifas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TarifasRepository extends JpaRepository<Tarifas, Long> {
}
