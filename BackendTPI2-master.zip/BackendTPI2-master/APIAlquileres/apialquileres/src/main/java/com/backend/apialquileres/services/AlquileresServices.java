package com.backend.apialquileres.services;

import com.backend.apialquileres.entities.Alquileres;
import com.backend.apialquileres.entitiesDTO.AlquileresDTO;
import com.backend.apialquileres.repository.AlquileresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AlquileresServices {

    @Autowired
    private AlquileresRepository alquileresRepository;

    public List<AlquileresDTO> getAllAlquiler() {
        List<Alquileres> alquileres = alquileresRepository.findAll();
        return alquileres.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    private AlquileresDTO convertToDto(Alquileres alquileres) {
        AlquileresDTO entity = new AlquileresDTO();
        entity.setId(alquileres.getId());
        entity.setIdCliente(alquileres.getIdCliente());
        entity.setEstado(alquileres.getEstado());
        entity.setId(alquileres.getEstacionRetiro().getId());
        entity.setEstacionRetiro(alquileres.getEstacionRetiro());
        entity.setEstacionDevolucion(alquileres.getEstacionDevolucion());
        entity.setFechaHoraRetiro(alquileres.getFechaHoraRetiro());
        entity.setFechaHoraDevolucion(alquileres.getFechaHoraDevolucion());
        entity.setMonto(alquileres.getMonto());
        entity.setIdTarifa(alquileres.getIdTarifa());
        return entity;
    }

    public AlquileresDTO findById(Long id) {
        return alquileresRepository.findById(id).map(this::convertToDto).orElse(null);
    }

    public AlquileresDTO save(AlquileresDTO alquilerDto) {
        Alquileres alquileres = convertToEntity(alquilerDto);
        Alquileres savedAlquileres = alquileresRepository.save(alquileres);
        return convertToDto(savedAlquileres);
    }

    private Alquileres convertToEntity(AlquileresDTO alquilerDto) {
        Alquileres entity = new Alquileres();
        entity.setId(alquilerDto.getId());
        entity.setIdCliente(alquilerDto.getIdCliente());
        entity.setEstado(alquilerDto.getEstado());
        entity.setEstacionRetiro(alquilerDto.getEstacionRetiro());
        entity.setEstacionDevolucion(alquilerDto.getEstacionDevolucion());
        entity.setFechaHoraRetiro(alquilerDto.getFechaHoraRetiro());
        entity.setFechaHoraDevolucion(alquilerDto.getFechaHoraDevolucion());
        entity.setMonto(alquilerDto.getMonto());
        entity.setIdTarifa(alquilerDto.getIdTarifa());
        return entity;
    }

    public AlquileresDTO update(Long id, AlquileresDTO alquilerDto) {
        Optional<Alquileres> existingAlquileres = alquileresRepository.findById(id);
        if (existingAlquileres.isPresent()) {
            Alquileres alquileres = convertToEntity(alquilerDto);
            alquileres.setId(alquilerDto.getId());
            Alquileres updatedAlquileres = alquileresRepository.save(alquileres);
            return convertToDto(updatedAlquileres);
        } else {
            return null;
        }
    }

    public void deleteById(Long id) {
        alquileresRepository.deleteById(id);
    }

}
