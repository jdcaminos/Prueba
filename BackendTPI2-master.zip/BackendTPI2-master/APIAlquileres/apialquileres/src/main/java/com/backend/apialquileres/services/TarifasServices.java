package com.backend.apialquileres.services;

import com.backend.apialquileres.entities.Tarifas;
import com.backend.apialquileres.entitiesDTO.TarifasDTO;
import com.backend.apialquileres.repository.TarifasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TarifasServices {
    @Autowired
    private TarifasRepository tarifasRepository;

    public List<TarifasDTO> getAllTarifas() {
        List<Tarifas> tarifas = tarifasRepository.findAll();
        return tarifas.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    private TarifasDTO convertToDto(Tarifas tarifas) {
        TarifasDTO entity = new TarifasDTO();
        entity.setId(tarifas.getId());
        entity.setTipoTarifa(tarifas.getTipoTarifa());
        entity.setDefinicion(tarifas.getDefinicion());
        entity.setDiaSemana(tarifas.getDiaSemana());
        entity.setDiaMes(tarifas.getDiaMes());
        entity.setMes(tarifas.getMes());
        entity.setAnio(tarifas.getAnio());
        entity.setMontoFijoAlquiler(tarifas.getMontoFijoAlquiler());
        entity.setMontoMinutoFraccion(tarifas.getMontoMinutoFraccion());
        entity.setMontoKm(tarifas.getMontoKm());
        entity.setMontoHora(tarifas.getMontoHora());
        return entity;
    }

    public TarifasDTO findById(Long id) {
        return tarifasRepository.findById(id).map(this::convertToDto).orElse(null);
    }

    public TarifasDTO save(TarifasDTO tarifaDto) {
        Tarifas tarifas = convertToEntity(tarifaDto);
        Tarifas savedTarifas = tarifasRepository.save(tarifas);
        return convertToDto(savedTarifas);
    }

    private Tarifas convertToEntity(TarifasDTO tarifaDto) {
        Tarifas entity = new Tarifas();
        entity.setId(tarifaDto.getId());
        entity.setTipoTarifa(tarifaDto.getTipoTarifa());
        entity.setDefinicion(tarifaDto.getDefinicion());
        entity.setDiaSemana(tarifaDto.getDiaSemana());
        entity.setDiaMes(tarifaDto.getDiaMes());
        entity.setMes(tarifaDto.getMes());
        entity.setAnio(tarifaDto.getAnio());
        entity.setMontoFijoAlquiler(tarifaDto.getMontoFijoAlquiler());
        entity.setMontoMinutoFraccion(tarifaDto.getMontoMinutoFraccion());
        entity.setMontoKm(tarifaDto.getMontoKm());
        entity.setMontoHora(tarifaDto.getMontoHora());
        return entity;
    }

    public TarifasDTO update(Long id, TarifasDTO tarifaDto) {
        Optional<Tarifas> existingTarifas = tarifasRepository.findById(id);
        if (existingTarifas.isPresent()) {
            Tarifas tarifas = convertToEntity(tarifaDto);
            tarifas.setId(tarifaDto.getId());
            Tarifas updatedTarifas = tarifasRepository.save(tarifas);
            return convertToDto(updatedTarifas);
        } else {
            return null;
        }
    }

    public void deleteById(Long id) {
        tarifasRepository.deleteById(id);
    }
}
