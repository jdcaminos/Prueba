package com.backend.apiestaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiestacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiestacionesApplication.class, args);
	}

}
