package com.backend.apiestaciones.controller;

import com.backend.apiestaciones.entitiesDTO.EstacionesDTO;
import com.backend.apiestaciones.services.EstacionesServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estaciones")
public class EstacionesController {
    @Autowired
    private EstacionesServices estacionesServices;

    @GetMapping()
    public ResponseEntity<List<EstacionesDTO>> getAllEstacion(){
        return ResponseEntity.ok(estacionesServices.getAllEstacion());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EstacionesDTO> getEstacionById(@PathVariable("id") Long id) {
        EstacionesDTO tarifa = estacionesServices.findById(id);
        if (tarifa != null) {
            return ResponseEntity.ok(tarifa);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping()
    public ResponseEntity<EstacionesDTO> createEstacion(@RequestBody EstacionesDTO estacionDto) {
        EstacionesDTO createdEstacion = estacionesServices.save(estacionDto);
        return ResponseEntity.ok(createdEstacion);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstacionesDTO> updateEstacion(@PathVariable("id") Integer id, @RequestBody EstacionesDTO estacionDto) {
        EstacionesDTO updatedEstacion = estacionesServices.update(id, estacionDto);
        if (updatedEstacion != null) {
            return ResponseEntity.ok(updatedEstacion);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEstacion(@PathVariable("id") Long id) {
        estacionesServices.deleteById(id);
        return ResponseEntity.noContent().build();
    }

}
