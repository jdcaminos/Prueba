package com.backend.apiestaciones.entitiesDTO;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class EstacionesDTO {
    private int id;
    private char nombre;
    private Timestamp fechaHoraCreacion;
    private float longitud;
    private float latitud;
}
