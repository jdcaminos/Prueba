package com.backend.apiestaciones.repository;

import com.backend.apiestaciones.entities.Estaciones;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EstacionesRepository extends JpaRepository<Estaciones, Long> {
}
