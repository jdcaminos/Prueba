package com.backend.apiestaciones.services;

import com.backend.apiestaciones.entities.Estaciones;
import com.backend.apiestaciones.entitiesDTO.EstacionesDTO;
import com.backend.apiestaciones.repository.EstacionesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EstacionesServices {
    @Autowired
    private EstacionesRepository estacionesRepository;

    public List<EstacionesDTO> getAllEstacion(){
        List<Estaciones> estaciones = estacionesRepository.findAll();
        return estaciones.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    private EstacionesDTO convertToDto(Estaciones estaciones) {
        EstacionesDTO entity = new EstacionesDTO();
        entity.setId(estaciones.getId());
        entity.setNombre(estaciones.getNombre());
        entity.setFechaHoraCreacion(estaciones.getFechaHoraCreacion());
        entity.setLongitud(estaciones.getLongitud());
        entity.setLatitud(estaciones.getLatitud());
        return entity;
    }

    public EstacionesDTO findById(Long id) {
        return estacionesRepository.findById(id).map(this::convertToDto).orElse(null);
    }

    public EstacionesDTO save(EstacionesDTO estacionDto) {
        Estaciones estaciones = convertToEntity(estacionDto);
        Estaciones savedEstacion = estacionesRepository.save(estaciones);
        return convertToDto(savedEstacion);
    }

    private Estaciones convertToEntity(EstacionesDTO estacionDto) {
        Estaciones entity = new Estaciones();
        entity.setId(estacionDto.getId());
        entity.setNombre(estacionDto.getNombre());
        entity.setFechaHoraCreacion(estacionDto.getFechaHoraCreacion());
        entity.setLatitud(estacionDto.getLatitud());
        entity.setLongitud(estacionDto.getLongitud());
        return entity;
    }

    public EstacionesDTO update(Integer id, EstacionesDTO estacionDto) {
        Estaciones estaciones = convertToEntity(estacionDto);
        estaciones.setId(id);
        Estaciones updatedEstaciones = estacionesRepository.save(estaciones);
        return convertToDto(updatedEstaciones);
    }

    public void deleteById(Long id) {
        estacionesRepository.deleteById(id);
    }
}
