package com.backend.apiestaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiestacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
